
document.getElementById('yr').textContent = new Date().getFullYear();
